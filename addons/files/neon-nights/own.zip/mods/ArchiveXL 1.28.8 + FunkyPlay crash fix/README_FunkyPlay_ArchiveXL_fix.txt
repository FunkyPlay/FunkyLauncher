ArchiveXL 1.28.8 + FunkyPlay crash fix
======================================

This is a MODIFIED build of ArchiveXL 1.28.8 by psiberx
(https://github.com/psiberx/cp2077-archive-xl), released under the MIT License (see LICENSE).
Modified by FunkyPlay (https://github.com/FunkyPlay), 2026-11-14. Install it OVER the official ArchiveXL 1.28.8.

UNOFFICIAL BUILD. Not made or supported by psiberx.
Please report problems with this build to FunkyPlay, not to the ArchiveXL author.

Changes (all marked "FunkyPlay test fix" in the source):
1. Garment/Extension.cpp - when the processor -> entity state link is missing or stale
   (fast reassembly: photo mode outfits, wardrobe, leaving a vehicle, camera switch),
   the entity state is found by the appearance part, so {gender}/{body} in dynamic mesh
   paths are still resolved. Without this the game loads "*...{body}.mesh", gets a null
   mesh and crashes (Cyberpunk2077.exe+0x4B2267, read 0x1E0).
2. Mesh/Extension.cpp - CMesh::FindAppearance is never called with a null mesh.
3. PuppetState/Extension.cpp - GetBodyType skips null components.
Every recovered case is logged to ArchiveXL.log as "[FunkyFix]".

ArchiveXL 1.28.8 + исправление вылета от FunkyPlay
--------------------------------------------------
Изменённая версия ArchiveXL 1.28.8 (автор psiberx, лицензия MIT — см. LICENSE).
НЕОФИЦИАЛЬНАЯ СБОРКА. Автор ArchiveXL её не делал и не поддерживает.
Об ошибках в этой сборке пишите FunkyPlay, не автору ArchiveXL.
Исправляет вылет при смене одежды, в фоторежиме, при выходе из машины и смене вида:
ArchiveXL иногда терял подстановку типа тела ({body}) в путь к модели вещи.
Когда выйдет официальное исправление — этот мод можно убрать.