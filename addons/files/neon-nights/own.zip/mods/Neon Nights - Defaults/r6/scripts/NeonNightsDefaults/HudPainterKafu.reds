// Neon Nights by Funky — default settings.
// Once, on the first start with this modlist, HUD Painter switches from DEFAULT to the "KAFU UI" preset.
// Uses only HUD Painter's public functions. If the player picks another preset later, it is kept.
module NeonNightsDefaults
import HudPainter.*

public class NeonNightsDefaultsService extends ScriptableService {
  private persistent let kafuApplied: Bool;

  private cb func OnInitialize() {
    if this.kafuApplied { return; }
    let painter: ref<HudPainterStorage> = HudPainterStorage.Get();
    if !IsDefined(painter) { return; }
    for preset in painter.GetAvailablePresetsList() {
      if Equals(preset.name, "KAFU UI") {
        if Equals(painter.GetActivePresetName(), painter.GetDefaultPresetName()) {
          painter.SaveActivePresetName("KAFU UI");
          painter.PatchCurrentInkStyleResource();
        }
        this.kafuApplied = true;
        return;
      }
    }
  }
}
